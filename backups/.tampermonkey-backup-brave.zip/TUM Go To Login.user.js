// ==UserScript==
// @name         TUM Go To Login
// @namespace    http://tampermonkey.net/
// @version      2024-01-12
// @description  Automatically login to tum!
// @author       You
// @match        https://www.moodle.tum.de/login/index.php
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// ==/UserScript==

(function () {
  "use strict";
  const TumLogin = document.querySelector("a[title='TUM LOGIN']");
  TumLogin.click();
})();


